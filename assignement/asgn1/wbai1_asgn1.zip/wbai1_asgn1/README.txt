This program was completed using pair programming.
Partner: Wentian Bai (wbai1@ucsc.edu)
Partner: Wentan Bai (webai@ucsc.edu)

We acknowledge that each partner in a programming pair should
drive roughly 50% of the time the pair is working together, and
at most 25% of an individual��s effort for an assignment should
be spent working alone. Any work done by a solitary programmer
must be reviewed by the partner. The object is to work
together, learning from each other, not to divide the work into
two pieces with each partner working on a different piece.

Wentian Bai spent 5 hours working alone.
Wentan Bai spent 5 hours working alone.
We spent 10 hours working together.
Ada Byron spent 2 hours driving.
Charles Babbage spent 2 hours driving.

Please grade the work submitted by wbai1@ucsc.edu
and not the work submitted by webai@ucsc.edu.

$Id: README,v 1.1 2017-04-22 13:05:55-07 - - $